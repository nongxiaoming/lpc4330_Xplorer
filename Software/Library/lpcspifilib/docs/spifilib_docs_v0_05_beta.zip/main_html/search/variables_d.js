var searchData=
[
  ['setopts',['setOpts',['../structSPIFI__DEV__T.html#a5afc82eddbeb4c322c847a388685ccdd',1,'SPIFI_DEV_T']]],
  ['spifictrladdr',['spifiCtrlAddr',['../structSPIFI__INFODATA__T.html#aa0d8ab4a14383606036491ce1340298d',1,'SPIFI_INFODATA_T']]],
  ['stat',['STAT',['../structLPC__SPIFI__CHIPHW__T.html#a1188f23c5d2b01b391559118d3654eac',1,'LPC_SPIFI_CHIPHW_T']]],
  ['subblks',['subBlks',['../structSPIFI__DEV__PDATA.html#ac89de4aec4cef3adc6a81ed758438d5a',1,'SPIFI_DEV_PDATA']]],
  ['subblksize',['subBlkSize',['../structSPIFI__DEV__PDATA.html#adcbad5afe37145df89c13c10082fa643',1,'SPIFI_DEV_PDATA']]],
  ['subblocksize',['subBlockSize',['../structSPIFI__INFODATA__T.html#a771f4339f8431370fedda736769f9088',1,'SPIFI_INFODATA_T']]]
];
