var searchData=
[
  ['pageprogram',['pageProgram',['../structSPIFI__DEV__T.html#a1b6ef0e4cdea0fac94dbb9eee58986fe',1,'SPIFI_DEV_T']]],
  ['pagesize',['pageSize',['../structSPIFI__INFODATA__T.html#a079dbd434f446879f065b79381d6c60f',1,'SPIFI_INFODATA_T::pageSize()'],['../structSPIFI__DEV__PDATA.html#a25525956ebb3a4adbf725e55f9d67e0b',1,'SPIFI_DEV_PDATA::pageSize()']]],
  ['pdesc',['pDesc',['../structSPIFI__DEV__FAMILY.html#a43d18f329bc5b09f328d7f120c674a4a',1,'SPIFI_DEV_FAMILY']]],
  ['pdev',['pDev',['../structSPIFI__HANDLE.html#a537fa1157ece6cbbca06dd2579e6274f',1,'SPIFI_HANDLE']]],
  ['pdevdata',['pDevData',['../structSPIFI__DEV__DATA.html#ab6b2b17d22fab00f6ca2474552852b34',1,'SPIFI_DEV_DATA::pDevData()'],['../structSPIFI__HANDLE.html#ac01714a9cee7f5831d05006e560020c9',1,'SPIFI_HANDLE::pDevData()']]],
  ['pdevname',['pDevName',['../structSPIFI__INFODATA__T.html#a53ff558b2de8c209e0bc792314563e03',1,'SPIFI_INFODATA_T::pDevName()'],['../structSPIFI__DEVDESC__T.html#a33cb1edcc6a827c3508e497079fdf040',1,'SPIFI_DEVDESC_T::pDevName()']]],
  ['pinfodata',['pInfoData',['../structSPIFI__HANDLE.html#a2505a17e8d4edccffc91c4cb2cd15ea0',1,'SPIFI_HANDLE']]],
  ['pnext',['pNext',['../structSPIFI__DEV__DATA.html#aa64cad420c905f1bc6e705e0fbd9346a',1,'SPIFI_DEV_DATA::pNext()'],['../structSPIFI__DEV__FAMILY.html#aec6fbd6e72da0e26ed520168667eacef',1,'SPIFI_DEV_FAMILY::pNext()']]],
  ['pprvdevdetect',['pPrvDevDetect',['../structSPIFI__DEVDESC__T.html#a85a7dab10da45468d1dcaea9135e161f',1,'SPIFI_DEVDESC_T']]],
  ['pprvdevregister',['pPrvDevRegister',['../structSPIFI__DEVDESC__T.html#acce967a57934349f2be6bd7f69727a1f',1,'SPIFI_DEVDESC_T']]],
  ['pprvdevsetup',['pPrvDevSetup',['../structSPIFI__DEVDESC__T.html#a07aa2553ecfac831ece1404f6377e435',1,'SPIFI_DEVDESC_T']]],
  ['prvdatasize',['prvDataSize',['../structSPIFI__DEVDESC__T.html#a367ee286d89921fc1cb328a3aa289188',1,'SPIFI_DEVDESC_T']]]
];
