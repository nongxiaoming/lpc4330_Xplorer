var searchData=
[
  ['cachelimit',['CACHELIMIT',['../structLPC__SPIFI__CHIPHW__T.html#ae253ede81a0e5a43d04f5795cf200158',1,'LPC_SPIFI_CHIPHW_T']]],
  ['caps',['caps',['../structSPIFI__INFODATA__T.html#aaea02f468f3f120a45fd85e94ff36c23',1,'SPIFI_INFODATA_T::caps()'],['../structSPIFI__DEV__PDATA.html#a5265b26a029adf9a3131495981f96eb0',1,'SPIFI_DEV_PDATA::caps()']]],
  ['cmd',['CMD',['../structLPC__SPIFI__CHIPHW__T.html#afbf71b18db7039717565c79665c7f1c9',1,'LPC_SPIFI_CHIPHW_T']]],
  ['ctrl',['CTRL',['../structLPC__SPIFI__CHIPHW__T.html#a00a7d324fa14f61330f3657eb6bc1d27',1,'LPC_SPIFI_CHIPHW_T']]]
];
