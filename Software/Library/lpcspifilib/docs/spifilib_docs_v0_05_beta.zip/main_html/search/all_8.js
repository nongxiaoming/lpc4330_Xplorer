var searchData=
[
  ['maxclkrate',['maxClkRate',['../structSPIFI__INFODATA__T.html#a53e8ed845727094b97077ed75450307b',1,'SPIFI_INFODATA_T::maxClkRate()'],['../structSPIFI__DEV__PDATA.html#a80299d9a3d02af3916330c6cc4239169',1,'SPIFI_DEV_PDATA::maxClkRate()']]],
  ['maxreadsize',['maxReadSize',['../structSPIFI__INFODATA__T.html#a4a4b44d180f107386290149b836de349',1,'SPIFI_INFODATA_T::maxReadSize()'],['../structSPIFI__DEV__PDATA.html#a946b7ec0e797b19f1ec057c757d0af94',1,'SPIFI_DEV_PDATA::maxReadSize()']]],
  ['memcmd',['MEMCMD',['../structLPC__SPIFI__CHIPHW__T.html#af13337f9c7bbeea4e0631f11546dfe67',1,'LPC_SPIFI_CHIPHW_T']]]
];
