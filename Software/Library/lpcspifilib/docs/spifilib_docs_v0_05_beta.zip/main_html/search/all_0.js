var searchData=
[
  ['addr',['ADDR',['../structLPC__SPIFI__CHIPHW__T.html#a8cb61e771d24b25ac406586890464e64',1,'LPC_SPIFI_CHIPHW_T']]],
  ['adding_20a_20new_20lpcspifilib_20library_20device',['Adding a new LPCSPIFILIB Library device',['../group__LPCSPIFILIB__NEWDEVFAM.html',1,'']]]
];
