var searchData=
[
  ['unlockblock',['unlockBlock',['../structSPIFI__DEV__T.html#a1fe812de36d084554697cc543f5ba452',1,'SPIFI_DEV_T']]],
  ['unlockdevice',['unlockDevice',['../structSPIFI__DEV__T.html#a04aefac228bbb4953df96ae0fbd9c1ad',1,'SPIFI_DEV_T']]]
];
