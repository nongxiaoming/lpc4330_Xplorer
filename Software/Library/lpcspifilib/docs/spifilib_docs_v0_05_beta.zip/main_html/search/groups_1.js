var searchData=
[
  ['copyright_20_28c_29_202013_20nxp_20semiconductors_2e_20all_20rights_20reserved_2e',['Copyright (C) 2013 NXP Semiconductors. All rights reserved.',['../group__LPCOPEN__NXP__COPYRIGHT.html',1,'']]]
];
