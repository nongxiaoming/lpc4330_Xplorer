var searchData=
[
  ['numblocks',['numBlocks',['../structSPIFI__INFODATA__T.html#a7926413a08d18e57518b4e83c269cabe',1,'SPIFI_INFODATA_T']]],
  ['numsubblocks',['numSubBlocks',['../structSPIFI__INFODATA__T.html#ab0311b6e3eefb0b0f69b2aa324e8001c',1,'SPIFI_INFODATA_T']]]
];
