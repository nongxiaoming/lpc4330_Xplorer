var searchData=
[
  ['baseaddr',['baseAddr',['../structSPIFI__INFODATA__T.html#afe2b46f76498bc5c2a17124629b49467',1,'SPIFI_INFODATA_T']]],
  ['blks',['blks',['../structSPIFI__DEV__PDATA.html#afb7ca91af660df357560df002463e362',1,'SPIFI_DEV_PDATA']]],
  ['blksize',['blkSize',['../structSPIFI__DEV__PDATA.html#af8702d16c69c395fae9e5f1b69577c8b',1,'SPIFI_DEV_PDATA']]],
  ['blocksize',['blockSize',['../structSPIFI__INFODATA__T.html#ad8e6a334393903348031e0f9adf91dbc',1,'SPIFI_INFODATA_T']]]
];
