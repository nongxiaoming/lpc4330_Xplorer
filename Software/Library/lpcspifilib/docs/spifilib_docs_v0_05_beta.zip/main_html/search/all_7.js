var searchData=
[
  ['lpcspifi_20library_20for_20the_20nxp_20microcontrollers',['LPCSPIFI Library for the NXP Microcontrollers',['../index.html',1,'']]],
  ['lasterr',['lastErr',['../structSPIFI__INFODATA__T.html#a9b38b463251f0e12376d5db8f248a40b',1,'SPIFI_INFODATA_T']]],
  ['lockblock',['lockBlock',['../structSPIFI__DEV__T.html#a1afab68e1c39d374d4a8b9c7b737a42a',1,'SPIFI_DEV_T']]],
  ['lockdevice',['lockDevice',['../structSPIFI__DEV__T.html#aea6b50aaa65aa0b4889f72036326eb38',1,'SPIFI_DEV_T']]],
  ['lpc_5fspifi_5fchiphw_5ft',['LPC_SPIFI_CHIPHW_T',['../structLPC__SPIFI__CHIPHW__T.html',1,'']]],
  ['lpcopen_20spifi_20flash_20library_20_28lpcspifilib_29',['LPCOpen SPIFI FLASH Library (LPCSPIFILIB)',['../group__LPCSPIFILIB.html',1,'']]],
  ['lpcspifilib_20common_20api_20functions',['LPCSPIFILIB common API functions',['../group__LPCSPIFILIB__API.html',1,'']]],
  ['lpcspifilib_20library_20build_20information',['LPCSPIFILIB library build information',['../group__LPCSPIFILIB__BUILD.html',1,'']]],
  ['lpcspifilib_20library_20support_20functions',['LPCSPIFILIB library support functions',['../group__LPCSPIFILIB__CMNAPI.html',1,'']]],
  ['lpcspifilib_20macronix_20mx25xxx5_20family_20device_20support',['LPCSPIFILIB Macronix MX25xxx5 family device support',['../group__LPCSPIFILIB__CONFIG__MX25.html',1,'']]],
  ['lpcspifilib_20spansion_20s25fl1k_20family_20device_20support',['LPCSPIFILIB Spansion S25FL1K family device support',['../group__LPCSPIFILIB__CONFIG__SA25FL1K.html',1,'']]],
  ['lpcspifilib_20spansion_20s25_20family_20device_20support',['LPCSPIFILIB Spansion S25 family device support',['../group__LPCSPIFILIB__CONFIG__SA25FLP.html',1,'']]],
  ['lpcspifilib_20device_20driver_20api_20functions',['LPCSPIFILIB device driver API functions',['../group__LPCSPIFILIB__DEV.html',1,'']]],
  ['lpcspifilib_20library_20device_20functions',['LPCSPIFILIB library device functions',['../group__LPCSPIFILIB__DEVAPI.html',1,'']]],
  ['lpcspifilib_20library_20drivers',['LPCSPIFILIB library drivers',['../group__LPCSPIFILIB__DRIVERS.html',1,'']]],
  ['lpcspifilib_20library_20helper_20functions',['LPCSPIFILIB library helper functions',['../group__LPCSPIFILIB__HELPAPI.html',1,'']]],
  ['lpcspifilib_20hardware_20definitions_20and_20api_20functions',['LPCSPIFILIB hardware definitions and API functions',['../group__LPCSPIFILIB__HW__API.html',1,'']]],
  ['lpcspifilib_20hardware_20support_20api_20functions',['LPCSPIFILIB hardware support API functions',['../group__LPCSPIFILIB__HW__L2.html',1,'']]],
  ['lpcspifilib_20primative_20api_20functions',['LPCSPIFILIB primative API functions',['../group__LPCSPIFILIB__HW__PRIM.html',1,'']]],
  ['lpcspifilib_20family_20registration_20functions',['LPCSPIFILIB family registration functions',['../group__LPCSPIFILIB__REGISTERHELPER.html',1,'']]],
  ['lpcspifilib_20library_20use_20model',['LPCSPIFILIB library use model',['../group__LPCSPIFILIB__USEMODEL.html',1,'']]]
];
