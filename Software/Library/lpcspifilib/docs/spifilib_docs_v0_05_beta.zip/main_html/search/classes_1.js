var searchData=
[
  ['spifi_5fdev_5fdata',['SPIFI_DEV_DATA',['../structSPIFI__DEV__DATA.html',1,'']]],
  ['spifi_5fdev_5ffamily',['SPIFI_DEV_FAMILY',['../structSPIFI__DEV__FAMILY.html',1,'']]],
  ['spifi_5fdev_5fpdata',['SPIFI_DEV_PDATA',['../structSPIFI__DEV__PDATA.html',1,'']]],
  ['spifi_5fdev_5ft',['SPIFI_DEV_T',['../structSPIFI__DEV__T.html',1,'']]],
  ['spifi_5fdevdesc_5ft',['SPIFI_DEVDESC_T',['../structSPIFI__DEVDESC__T.html',1,'']]],
  ['spifi_5fhandle',['SPIFI_HANDLE',['../structSPIFI__HANDLE.html',1,'']]],
  ['spifi_5finfodata_5ft',['SPIFI_INFODATA_T',['../structSPIFI__INFODATA__T.html',1,'']]]
];
