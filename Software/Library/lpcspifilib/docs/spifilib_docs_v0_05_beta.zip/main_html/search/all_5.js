var searchData=
[
  ['getdevname',['getDevName',['../structSPIFI__DEV__T.html#a32c30a5e8d8a53437dbcfe0f13550936',1,'SPIFI_DEV_T']]],
  ['getinfo',['getInfo',['../structSPIFI__DEV__T.html#a760dbfa34785969c78f7703ee309a17f',1,'SPIFI_DEV_T']]],
  ['getmemmodecmd',['getMemModeCmd',['../structSPIFI__DEV__T.html#a65bff5dda2944b8e098955e838981e86',1,'SPIFI_DEV_T']]]
];
