var searchData=
[
  ['lasterr',['lastErr',['../structSPIFI__INFODATA__T.html#a9b38b463251f0e12376d5db8f248a40b',1,'SPIFI_INFODATA_T']]],
  ['lockblock',['lockBlock',['../structSPIFI__DEV__T.html#a1afab68e1c39d374d4a8b9c7b737a42a',1,'SPIFI_DEV_T']]],
  ['lockdevice',['lockDevice',['../structSPIFI__DEV__T.html#aea6b50aaa65aa0b4889f72036326eb38',1,'SPIFI_DEV_T']]]
];
