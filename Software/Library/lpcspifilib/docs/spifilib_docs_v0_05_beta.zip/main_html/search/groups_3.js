var searchData=
[
  ['support_20required_20outside_20the_20lpcspifilib_20library',['Support required outside the LPCSPIFILIB Library',['../group__LPCSPIFILIB__NOTSUPP.html',1,'']]]
];
