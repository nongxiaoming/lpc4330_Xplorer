var searchData=
[
  ['dat16',['DAT16',['../structLPC__SPIFI__CHIPHW__T.html#a0ff56479b97dbd26e9fe6562b2b759d6',1,'LPC_SPIFI_CHIPHW_T']]],
  ['dat32',['DAT32',['../structLPC__SPIFI__CHIPHW__T.html#a45525d5273e157ba7acc003e126ae4ab',1,'LPC_SPIFI_CHIPHW_T']]],
  ['dat8',['DAT8',['../structLPC__SPIFI__CHIPHW__T.html#a3f14af3e2bac51fbec5048252eb51219',1,'LPC_SPIFI_CHIPHW_T']]],
  ['datintm',['DATINTM',['../structLPC__SPIFI__CHIPHW__T.html#abd78e711bbab805ac78625e57e448aa9',1,'LPC_SPIFI_CHIPHW_T']]],
  ['deinit',['deInit',['../structSPIFI__DEV__T.html#acb12b11729b243b6324a8e4ef0e1b841',1,'SPIFI_DEV_T']]]
];
