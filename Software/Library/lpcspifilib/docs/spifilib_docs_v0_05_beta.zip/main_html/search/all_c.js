var searchData=
[
  ['read',['read',['../structSPIFI__DEV__T.html#aea8ce385fc40f938b3afa7954ca79047',1,'SPIFI_DEV_T']]],
  ['reset',['reset',['../structSPIFI__DEV__T.html#a4c0837ba09a6f028c151dd1d036d7e31',1,'SPIFI_DEV_T']]]
];
