var searchData=
[
  ['id',['id',['../structSPIFI__INFODATA__T.html#a1ca7e6f8b9271e7ae76d0c263b317e4f',1,'SPIFI_INFODATA_T::id()'],['../structSPIFI__DEV__PDATA.html#a3c0fc3229b67aa3426c49ffaa630e3ef',1,'SPIFI_DEV_PDATA::id()']]],
  ['init',['init',['../structSPIFI__DEV__T.html#a9848cd027ffc75ff4a02efc1c53b929b',1,'SPIFI_DEV_T']]]
];
