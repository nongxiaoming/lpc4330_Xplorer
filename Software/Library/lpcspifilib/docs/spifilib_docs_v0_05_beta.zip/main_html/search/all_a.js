var searchData=
[
  ['opts',['opts',['../structSPIFI__INFODATA__T.html#aa28d92236a3c771516f4f1b0f3465340',1,'SPIFI_INFODATA_T']]]
];
