var searchData=
[
  ['lpcopen_20spifi_20flash_20library_20_28lpcspifilib_29',['LPCOpen SPIFI FLASH Library (LPCSPIFILIB)',['../group__LPCSPIFILIB.html',1,'']]],
  ['lpcspifilib_20common_20api_20functions',['LPCSPIFILIB common API functions',['../group__LPCSPIFILIB__API.html',1,'']]],
  ['lpcspifilib_20library_20build_20information',['LPCSPIFILIB library build information',['../group__LPCSPIFILIB__BUILD.html',1,'']]],
  ['lpcspifilib_20library_20support_20functions',['LPCSPIFILIB library support functions',['../group__LPCSPIFILIB__CMNAPI.html',1,'']]],
  ['lpcspifilib_20macronix_20mx25xxx5_20family_20device_20support',['LPCSPIFILIB Macronix MX25xxx5 family device support',['../group__LPCSPIFILIB__CONFIG__MX25.html',1,'']]],
  ['lpcspifilib_20spansion_20s25fl1k_20family_20device_20support',['LPCSPIFILIB Spansion S25FL1K family device support',['../group__LPCSPIFILIB__CONFIG__SA25FL1K.html',1,'']]],
  ['lpcspifilib_20spansion_20s25_20family_20device_20support',['LPCSPIFILIB Spansion S25 family device support',['../group__LPCSPIFILIB__CONFIG__SA25FLP.html',1,'']]],
  ['lpcspifilib_20device_20driver_20api_20functions',['LPCSPIFILIB device driver API functions',['../group__LPCSPIFILIB__DEV.html',1,'']]],
  ['lpcspifilib_20library_20device_20functions',['LPCSPIFILIB library device functions',['../group__LPCSPIFILIB__DEVAPI.html',1,'']]],
  ['lpcspifilib_20library_20drivers',['LPCSPIFILIB library drivers',['../group__LPCSPIFILIB__DRIVERS.html',1,'']]],
  ['lpcspifilib_20library_20helper_20functions',['LPCSPIFILIB library helper functions',['../group__LPCSPIFILIB__HELPAPI.html',1,'']]],
  ['lpcspifilib_20hardware_20definitions_20and_20api_20functions',['LPCSPIFILIB hardware definitions and API functions',['../group__LPCSPIFILIB__HW__API.html',1,'']]],
  ['lpcspifilib_20hardware_20support_20api_20functions',['LPCSPIFILIB hardware support API functions',['../group__LPCSPIFILIB__HW__L2.html',1,'']]],
  ['lpcspifilib_20primative_20api_20functions',['LPCSPIFILIB primative API functions',['../group__LPCSPIFILIB__HW__PRIM.html',1,'']]],
  ['lpcspifilib_20family_20registration_20functions',['LPCSPIFILIB family registration functions',['../group__LPCSPIFILIB__REGISTERHELPER.html',1,'']]],
  ['lpcspifilib_20library_20use_20model',['LPCSPIFILIB library use model',['../group__LPCSPIFILIB__USEMODEL.html',1,'']]]
];
