var searchData=
[
  ['eraseall',['eraseAll',['../structSPIFI__DEV__T.html#ae42f9e4dc2313ab852b1de8240808616',1,'SPIFI_DEV_T']]],
  ['eraseblock',['eraseBlock',['../structSPIFI__DEV__T.html#a0994f4825c74ad193f85346a16d9c929',1,'SPIFI_DEV_T']]],
  ['erasesubblock',['eraseSubBlock',['../structSPIFI__DEV__T.html#aca79d65e4b9759bdba6ff81001ff9a7c',1,'SPIFI_DEV_T']]]
];
